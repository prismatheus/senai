var palavra = (prompt("Digita uma palavra vo botar ela ao contrario"))

const letra = palavra.split('')

alert(letra.reverse().join(''))