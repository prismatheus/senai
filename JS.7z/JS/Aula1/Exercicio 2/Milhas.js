var km = Number(prompt("Digite uma distancia em km:"))

const miles = (km*0.621371)

alert("Essa distancia em Milhas é de:"+miles.toFixed(2)+".")