

    alert(pegarSalario())

function pegarSalario() {

    let salario = Number(prompt("Digite seu salario:"))
    let imposto = salario*0.15
    let salarioImposto = salario-imposto

    return "O seu salario bruto é: " + salario.toFixed(2) +
        "\n O imposto inserido no seu salario é de: " + imposto.toFixed(2) +
        "\n E o seu salario depois dos impostos é: " + salarioImposto.toFixed(2)
}
