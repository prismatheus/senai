var num1 = Number(prompt("DiGITE UM NUMERO: "))
var num2 = Number(prompt("Digite outro numero: "))

let soma = num1+num2
let subt = num1-num2
let vzs = num1*num2
let div = num1/num2

alert("As contas são: \n"+soma.toFixed(2)+"\n"+subt.toFixed(2)+"\n"+vzs.toFixed(2)+"\n"+div.toFixed(2))