

    var num1 = Number(prompt("DiGITE UM NUMERO: "))
    var num2 = Number(prompt("Digite outro numero: "))
    var operacao = (prompt("Digite a operação que você quer executar: "))
    let soma
   if(operacao == "/"){
        soma = num1/num2
    
   }
   if(operacao == "*"){
        soma = num1*num2
    
   }
   if(operacao == "+"){
        soma = num1+num2
    
   }
   if(operacao == "-"){
        soma = num1-num2
    
   }
   alert(soma.toFixed())