function descontado(qtdIngressos) {
  let ingresso = 27;
  let total = ingresso * qtdIngressos;
  return `Com o desconto, os ingressos ficaram R$${total.toFixed(2)}`;
}
function naoDescontado(qtdIngressos) {
    let ingresso = 30;
    let total = ingresso * qtdIngressos;
    return `Sem o desconto, os ingressos ficaram R$${total.toFixed(2)}`;
  }

  let pedido = Number(prompt("Bem-vindo! Digite a quantidade de ingressos que você desejaria comprar."));

for (let i = 0; i < 1; i++) {
	  let descontar =  Number(prompt(`Você faz parte do clube de descontos do cinema? (0 ou 1)`));
	
	if ((descontar == 0)) {
	    alert(descontado(pedido));
	}
	else if ((descontar == 1)) {
	    alert(naoDescontado(pedido))
	}
	else{
	    alert("prompt incorreto! tente novamente!")
        i--
	}
	
}