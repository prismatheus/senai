
let distanciaTotal = Number(prompt("digite a distancia a ser percorrida"));

let transporteUsado = prompt("digite o transporte que você irá utilizar na sua viagem: (carro/bicicleta/onibus/avião)");

viagem(distanciaTotal,transporteUsado)
function viagem(distancia,transporte) {    
    let velocidade = Number;
  let total;
	switch (transporte) {
	    case "carro":
	      velocidade = 100;
	      total = distancia / velocidade;
	      break;
	    case "bicicleta":
	      velocidade = 30;
	      total = distancia / velocidade;
	      break;
	    case "aviao":
	      velocidade = 300;
	      total = distancia / velocidade;
	      break;
	    case "onibus":
	      velocidade = 80;
	      total = distancia / velocidade;
	      break;
	    default:
	      alert("prompt incorreto.");
	      break;
          
}

  alert(`O tempo necessário para percorrer essa distância em hrs é:\n${total.toFixed(2)}hrs.`)
}
