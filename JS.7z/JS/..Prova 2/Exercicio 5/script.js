const numeroSorteado = Number((Math.random() * 100).toFixed(0));

let qtdPalpites = [];

for (let i = 0; i < 1; i++) {
  let palpite = Number(
    prompt(
      "Digite um numero entre 0 e 100 e tente adivinhar o número sorteado com as minhas dicas."
    )
  );
  if (palpite < 0 || palpite > 100) {
    alert("numero inválido, tenta denovo!");
    i--;
  } else {
      if (palpite > numeroSorteado) {
        alert("o número é sorteado é menor q esse q vc botou ai...");
        qtdPalpites.push(palpite);
        i--;
      }
      else if (palpite < numeroSorteado) {
        alert("o número que eu sorteei é maior q esse palpite!");
        qtdPalpites.push(palpite);
        i--;
      }
      else if ((palpite = numeroSorteado)) {
        alert(`PARABÉNS!! Você acertou!! O numero era ${palpite}!\n
As tentativas necessárias para acertar o numero sorteado foram: ${(qtdPalpites.length)+1} tentativa(s)`);
      }
    }
  }
