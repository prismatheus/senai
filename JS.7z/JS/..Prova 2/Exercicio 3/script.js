let exclamacao = ["!"];

for (let i = 10; i > 0; i--) {
  alert(`${i}${exclamacao}`);
  exclamacao.join("")
  exclamacao.push("!");
  
}
alert("Foguete lançado!");
