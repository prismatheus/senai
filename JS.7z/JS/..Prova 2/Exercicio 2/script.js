let total = 0
let orcamento = Number(prompt("Digite o orçamento para esse mês:"));
for (let i = 0; i < 1; i++) {
  let escolha = Number(
    prompt(
      "O que você gostaria se fazer? \n1=adicionar um gasto \n0=ver total e sair"
    )
  );

  switch (escolha) {
    case 1:
      dinheiroGasto = Number(prompt("Digite o dinheiro gasto:"));
      total = total + dinheiroGasto;
      console.log(total)
      i--;
      break;
    case 0:
      if(total > orcamento){
        alert(`Você gastou R$${total.toFixed(2)} e está FORA do orçamento de R$${orcamento.toFixed(2)}\nVamo dar uma economizada pô.`)
      }
      else{
        alert(`Você gastou R$${total.toFixed(2)} e está DENTRO do orçamento de R$${orcamento.toFixed(2)}\nParabéns maninho!`)
      }
      break;
    default:
        i--
      break;
  }
}
