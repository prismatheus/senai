let theDogs = ["A", "B", "C", "D", "E"];
let aux = 0;
let phrase1 = "",
  phrase2 = "",
  phrase3 = "";
let inNum,
  soma = 0,
  big = 0,
  small = Infinity;
while (aux != 5) {
  inNum = Number(
    prompt(
      `type out the note n#:${theDogs[aux]} for the ornamental jump competition's participant`
    )
  );
  if (inNum < small) {
    small = inNum;
  }
  if (inNum > big) {
    big = inNum;
  }
  console.log(inNum);
  aux++;

  soma += inNum;
}
soma = (soma - big - small) / 3;
phrase1 = "A media ficou " + soma.toFixed(2);
phrase2 = "O maior é " + big;
phrase3 = "O menor é " + small;
console.log(small);
console.log(big);
console.log(soma);

document.getElementById("sherk1").innerHTML = phrase1;
document.getElementById("sherk2").innerHTML = phrase2;
document.getElementById("sherk3").innerHTML = phrase3;