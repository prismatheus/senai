let escolha = prompt("Converções:\nTEMPO=A\nDISTANCIAS=B\nPESO=C");

switch (escolha.toLowerCase()) {
  case "a":
    converterTempo();
    break;
  case "b":
    converterDistancia();
    break;
  case "c":
    converterPeso();
    break;
}

function converterTempo() {
  let tempo = Number(
    prompt("Digite o tempo que você quer convertido (Em minutos OU horas)")
  );
  let convercaoTempo = prompt(
    "Digite a converção que você deseja: MINUTO/HORA=A\nHORA/MINUTO=B"
  );

  switch (convercaoTempo.toLowerCase()) {
    case "a":
      var tempoConvertido = tempo / 60;
      alert(`MINUTO/HORA: ${tempoConvertido.toFixed(2)}`);
      break;
    case "b":
      var tempoConvertido = tempo * 60;
      alert(`HORA/MINUTO: ${tempoConvertido.toFixed(2)}`);
      break;
  }
}
function converterDistancia() {
  let distancia = Number(
    prompt(
      "Digite a distancia que você quer convertido (Em metros OU kilometros)"
    )
  );
  let convercaoDistancia = prompt(
    "Digite a converção que você deseja: METRO/KILOMETRO=A\nKILOMETRO/METRO=B"
  );

  switch (convercaoDistancia) {
    case "a":
      var distanciaConvertida = distancia / 1000;
      alert(`METRO/KILOMETRO: ${distanciaConvertida.toFixed(2)}`);
      break;
    case "b":
      var distanciaConvertida = distancia * 1000;
      alert(`KILOMETRO/METRO: ${distanciaConvertida.toFixed(2)}`);
      break;
  }
}
function converterPeso() {
  let peso = Number(
    prompt("Digite o peso que você quer convertido (Em Kilogramas OU Libras)")
  );
  let convercaoPeso = prompt(
    "Digite a converção que você deseja: LIBRAS/KILOGRAMAS=A\nKILOGRAMAS/LIBRAS=B"
  );

  switch (convercaoPeso) {
    case "a":
      var pesoConvertido = peso / 2.20462;
      alert(`LIBRAS/KIILOGRAMAS: ${pesoConvertido.toFixed(2)}`);
      break;
    case "b":
      var pesoConvertido = peso * 2.20462;
      alert(`KIILOGRAMAS/LIBRAS: ${pesoConvertido.toFixed(2)}`);
      break;
  }
}
