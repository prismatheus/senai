let fruta = prompt("qual é a fruta?");

for (let index = 0; index < 1; index++) {
  switch (fruta.toLowerCase()) {
    case "uva":
      alert("Uva: R$19.99/kg");
      break;
    case "maça": case "maçã":   
      alert("Maçã: R$13.49/kg");
      break;
    case "banana":
      alert("Banana: R$12.99/kg");
    default:
      fruta = prompt("Invalido. Tente novamente!");
      index--;
      break;
  }
}
