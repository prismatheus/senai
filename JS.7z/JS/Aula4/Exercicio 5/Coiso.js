let num = Number(prompt("Digite um numero vo fala se ele é prime ou n prime"));
let aux = 0;
let phrase1 = "erro";
aux = num;
let divisor = 0;
while (aux != 0) {
  if (num % aux == 0) {
    divisor++;
  }
  aux--;
}
if (divisor == 2) {
  phrase1 = "é prime";
} else {
  phrase1 = "não prime";
}
console.log(phrase1);
document.getElementById("sherk").innerHTML = phrase1;
