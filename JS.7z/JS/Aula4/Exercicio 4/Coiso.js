let genero = prompt(
  "digite o genero de filme desejado para as recomendações:\n Comédia\n Drama\n Terror \n Suspense \n Ação"
);

pegaNumero(genero)

function pegaNumero(generoDeFilme) {
  switch (generoDeFilme.toLowerCase()) {
    case "comédia":
    case "comedia":
      alert(
        "Filmes de Comédia:\n Gente Grande (Coletânea)\n Click!\n Segurança de Shopping (Coletânea)"
      );
      break;
    case "drama":
      alert(
        "Filmes de Drama:\n Estou Pensando em Acabar com Tudo\n A Baleia\n Som do Silêncio"
      );
      break;
    case "terror":
      alert("Filmes de Terror:\n A Entidade\n IT: A Coisa\n REC");
      break;
    case "suspense":
      alert(
        "Filmes de Suspense:\n Ilha do Medo:\n Perfect Blue\n Amnésia\n O Operário"
      );
      break;
    case "ação":
    case "açao":
    case "acão":
    case "acao":
      alert(
        "Filmes de Ação:\n Velozes e Furiosos:\n Ghost in A Shell\n Missão Impossível\n Apocalypse Now"
      );
  }
  return generoDeFilme
}
