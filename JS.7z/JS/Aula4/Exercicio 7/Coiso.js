let num = Math.floor(Math.random() * 100);
let frase = "";
console.log(num);
let aux = 0;

let adivinhacao = Number(prompt("Digite um numero para tentar adivinha-lo"));
while (aux != 10) {
  if (adivinhacao > num) {
    adivinhacao = Number(prompt("Erro, o numero é menor que isso."));
    aux++;
  }
  if (adivinhacao < num) {
    adivinhacao = Number(prompt("Erro, o numero é MAIOR que isso."));
    aux++;
  }
  if (adivinhacao == num) {
    phrase1 = "acerto ggwp";
    aux = 10;
  } else {
    phrase1 = "tu é mto ruim";
  }
}
document.getElementById("sherk").innerHTML = phrase1;
