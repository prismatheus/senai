let form = document.querySelector("form")
let inNum = document.querySelector("numero")
let total
form.onsubmit=function(event){
  event.preventDefault()
  total = inNum+2
  console.log(total)
  document.getElementById("textos").innerHTML = total
}
