let inNum = Number(prompt("Digite um numero:"));
let total = 0
  let expo = inNum;

for (var i = 0; i <= inNum; i++) {
  total += expo; // 
  expo--

  console.log(expo)
  console.log(total)
}
alert(total)