let nome, idade, senha;

document
  .getElementById("inputForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    nome = document.getElementById("nome").value;
    idade = document.getElementById("idade").value;
    senha = document.getElementById("senha").value;

    console.log(nome);
    console.log(idade);
    console.log(senha);

    document.getElementById("nome").value = "";
    idade = document.getElementById("idade").value = "";
    senha = document.getElementById("senha").value = "";
  });

function mostrarSenha() {
  var mostrada = document.getElementById("senha");

  if (mostrada.type === "password") {
    mostrada.type = "text";
  } else {
    mostrada.type = "password";
  }
}
