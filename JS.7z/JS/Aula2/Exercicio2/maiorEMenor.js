let numero1 = Number(prompt("digite o numero 1"))
let numero2 = Number(prompt("digite o numero 2"))

if(numero1>numero2){
    alert("O numero "+numero1+" é o maior e o numero "+numero2+" é o menor")
} 
    if(numero2>numero1){
        alert("O numero "+numero2+" é o maior e o numero "+numero1+" é o menor")
    } 
        if(numero1==numero2){
            alert("Os numero são iguals")
        }