let idade = Number(prompt("Digite a sua idade:"))

if(idade<16){
    alert("Você não é velho o suficiente pra votar!")
}   
    else if(idade>=16 && idade<18){
        alert("Voce pode votar opcionalmente.")
    }
        else if(idade>=18){
            alert("Você é obrigado à votar!")
        }