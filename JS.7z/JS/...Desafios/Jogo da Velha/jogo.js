let jogo = [
['','',''],
['','',''],
['','',''],
]

let jogador1 = 'X'
let jogador2 = 'O'

function jogoEpa() {
    
    background(220)
    let largura = width/3
    let altura = height/3
    for (let i = 0;i < 3;i++){
        for (let j = 0; j < 3; j++){
            
    let lugar = [i][j]
            text()

        }
    }
}

