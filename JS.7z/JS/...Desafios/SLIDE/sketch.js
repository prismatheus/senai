let source;
let colunas = 4;
let fileiras = 4;
let l, a;

function preload() {
  source = loadImage("sherk.png");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
