

function funcaoSegundoGrau(a, b, c)
{
  let delta = b ** 2 - 4 * a * c;

  let x1 = -b + (Math.sqrt(delta) / 2) * a;
  let x2 = -b - (Math.sqrt(delta) / 2) * a;

  let result = `\n ${x1.toFixed(3)}\n ${x2.toFixed(3)}`;
  return result;
}


 console.log(funcaoSegundoGrau(55.7373, 12.52672, 8.526261))
