document
  .getElementById("inputForm")
  .addEventListener("submit", function (event) {
    event.preventDefault(); 

    const valor1 = document.getElementById("input1").value;
    const valor2 = document.getElementById("input2").value;

    
  })()