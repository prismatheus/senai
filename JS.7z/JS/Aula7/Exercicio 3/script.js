function calculaCorrente(tensao, corrente) {
  let resistencia = tensao / corrente;
  return resistencia;
}
let conta = calculaCorrente(1000, 42);

console.log("a conta é " + conta.toFixed(3));
