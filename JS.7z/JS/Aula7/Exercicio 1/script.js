function input(a, b, c) {
  return bigNumero(a,b,c), smallNumero(a,b,c);
}

function bigNumero(a,b,c) {
  var big = -Infinity;

  if (a > big) {
    big = a;
  }
  if (b > big) {
    big = b;
  }
  if (c > big) {
    big = c;
  }
  alert("o maior numero é " + big);
}
function smallNumero(a,b,c) {
  var small = Infinity+1;
              Infinity
  if (a < small) {
    small = a;
  }
  if (b < small) {
    small = b;
  }
  if (c < small) {
    small = c;
  }
  alert("o menor numero é " + small);
}

input(2000000000,55555555,1);
