let sorteado
let par = [],
    impar = []


for (let i = 0; i < 10; i++) {
	sorteado = parseInt(Math.random()*50)
	console.log(sorteado);
	if(sorteado%2==0){
        par.push(sorteado)
	}
	else{
        impar.push(sorteado)

	}
}
console.log(`numeros pares:${par.sort((a, b) => a -b)}`);
console.log(`numeros impares:${impar.sort((a, b) => a -b)}`);