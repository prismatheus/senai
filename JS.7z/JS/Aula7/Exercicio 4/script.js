let casamento = function (noive1, noive2, convidade, data, horario, local) {
  let mensagem = console.log(
    `Para:${convidade}\n Olá!! você está sendo convidado para o casamento do ${noive1} e da ${noive2}.\n No dia ${data}, as ${horario}hrs, em ${local}.\n Com muito carinho, ${noive1} e ${noive2}`
  );
  return mensagem;
};

casamento("Matt", "Malu", "Tio Lu", "16/10/2024", "18", "São José");
