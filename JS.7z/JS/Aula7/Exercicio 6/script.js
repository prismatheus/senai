
function isDivisible(numero, ...outrosNumberos){
    return outrosNumberos.every(n => numero % n === 0)
}