let dBacteria = [],
  dVirus = [],
  dAmbos = [];

for (let o = 0; o < 1; o++) {
  escolha = Number(
    prompt(
      "digite o que voce quer fazer: 1-adicionar doença, 2-visualizar lista de doenças, 3-sair"
    )
  );

  switch (escolha) {
    case 1:
      adicionarDoenca();
      o--;
      break;
    case 2:
      visualizarLista();
      o--;
      break;
    case 3:
      alert("adeus!");
      o++
      break;
      default:
        alert("prompt incorreto! tente novamente");
        o--
  }
}

function adicionarDoenca() {
  for (let i = 0; i < 1; i++) {
    let qualLista = Number(
      prompt(
        "em qual lista você gostaria de adicionar a doença?\n1-virus\n2-bacteria\n3-ambos\n4-voltar"
      )
    );
    switch (qualLista) {
      case 1:
        let virus = prompt("Qual é o nome do vírus?");
        dVirus.push(virus);
        i--;
        break;
      case 2:
        let bacteria = prompt("Qual é o nome da bactéria?");
        dBacteria.push(bacteria);
        i--;
        break;
      case 3:
        let ambos = prompt("Qual é o nome da doença?");
        dAmbos.push(ambos);
        i--;
        break;
      case 4:
        alert("voltando...");
        break;
        default:
        alert("prompt incorreto! tente novamente");
        i--
    }
  }
}
function visualizarLista() {
  for (let u = 0; u < 1; u++) {
    let visuLista = Number(
      prompt(
        "qual lista você gostaria de visualizar?\n1-virus\n2-bacteria\n3-ambos\n4-voltar"
      )
    );
    switch (visuLista) {
      case 1:
        alert(dVirus.join(", "));
        u--;
        break;
      case 2:
        alert(dBacteria.join(", "));
        u--;
        break;
      case 3:
        alert(dAmbos.join(", "));
        u--;
        break;
      case 4:
        alert("voltando...");
        break;
        default:
        alert("prompt incorreto! tente novamente");
        u--
    }
  }
}
