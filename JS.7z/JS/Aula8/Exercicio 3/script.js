let valores = []

for (let i = 0; i < 5; i++) {
  let valor = Number(prompt("digite um valor:"))
  valores.push(valor)
}
let valoresMaiores = valores.filter((valorMaior) =>{
return valorMaior > 50
})
alert(`valores maiores: ${valoresMaiores.join(", ")}`)