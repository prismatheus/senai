let idadesArray = []
for (let i = 0; i < 5; i++) {
let idade = prompt("digite uma idade")
idadesArray.push(idade)
}
let maiores = idadesArray.every(checarMaiorIdade)
function checarMaiorIdade(idades){
  return idades>=18
}
if(maiores){
  alert("todo mundo maior")
}
else{
  alert("nem todo mundo é maior")
}
console.log(idadesArray);
console.log(idadesArray.length);