const valores = [];
for (let i = 0; i < 5; i++) {
  let pegarValor = parseInt(prompt("digite um valor"))
  valores.push(pegarValor)
}

let maiorValor = valores.reduce((max, numero) => 
(numero > max ? numero : max), valores[0]);

alert(`o maior valor é ${maiorValor}`)