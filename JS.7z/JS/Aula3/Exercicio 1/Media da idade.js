let idade = []
let nome = []
let soma = 0
let idadeMaior = -999999999
let maisVelho
for(var aux=0;aux!=5;aux++){
    nome[aux]=prompt("digite seu nome")
    idade[aux]=Number(prompt("digite sua idade"))
    soma+=idade[aux]
if(idade[aux]>idadeMaior){
    idadeMaior=idade[aux]
    maisVelho=nome[aux]
    
}
}

let media = (soma/(idade.length))

for(var aux=0;aux!=5;aux++){
    console.log(nome[aux]+" "+idade[aux]+"\n")
}

console.log(`A media das idades é: ${media} \nE a pessoa mais velha é ${maisVelho} com ${idadeMaior} anos.`)