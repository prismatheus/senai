const usuarioCorreto = "Matheus";
const senhaCorreta = "homens123";
let usuario = prompt("digite o nome do usuário: ");
let senha = prompt("digite a senha do usuário: ");

var aux1 = 0;
var aux2 = 0;

while (aux1 < 1) {
  if (usuario == usuarioCorreto) {
    console.log("nome de usuário correto.");
    aux1++;
  } else {
    usuario = prompt("nome de usuário incorreto!!! tente novamente.");
  }
  while (aux2 < 1) {
    if (senha == senhaCorreta) {
      console.log("senha correta.");
      aux2++;
    } else {
      senha = prompt("senha incorreta!!! tente novamente.");
    }
  }
}

alert(`Bem vindo ${usuario}!`);
